
Error calling startBuild: User: arn:aws:sts::163859100295:assumed-role/AWS-CodePipeline-Service/1484250749500
is not authorized to perform: codebuild:StartBuild on resource:
arn:aws:codebuild:us-west-2:163859100295:project/Phantom (Service: AWSCodeBuild; Status Code: 400; Error Code: AccessDeniedException; Request ID: a679b48c-d900-11e6-b1a9-5f8644bfcde2)


Action execution failed
Error calling startBuild: User: arn:aws:sts::163859100295:assumed-role/AWS-CodePipeline-Service/1484250985081
is not authorized to perform: codebuild:StartBuild on resource:
arn:aws:codebuild:us-west-2:163859100295:project/Phantom(Service: AWSCodeBuild; Status Code: 400; Error Code: AccessDeniedException; Request ID: 33085eab-d901-11e6-8182-f746050e1c06)